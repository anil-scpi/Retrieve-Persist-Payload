import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper;
import groovy.Xml.*
import groovy.xmlSlurper.*

def Message processData(Message message) {
    //Get Body 
    def body = message.getBody(String.class);
    def payload = new XmlSlurper().parseText(body);
    def link = payload.entry.id
    
    message.setProperty("link",link)
    return message
}